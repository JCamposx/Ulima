package pe.edu.ulima.pm.covid19tool

class Constantes {
    companion object {
        const val SP = "SP_APP"
        const val SP_IS_SYNC = "IS_SYNC"
        const val SP_1ST_TIME = "1ST_TIME"
    }
}